<?php
require 'db.php';
require 'checks.php';

// Catalogue: the same labs and links as the original index page, grouped.
// Each lab: [id (used for progress tracking), number, link, is challenge]
$catalogue = [
    'auth' => [
        'name'   => 'Authentication & Authorization Attacks',
        'short'  => 'Auth',
        'groups' => [
            'Auth' => [
                ['a0x01', '0x01', 'labs/a0x01.php', false],
                ['a0x02', '0x02', 'labs/a0x02.php', false],
                ['a0x03', '0x03', 'labs/a0x03.php', true],
                ['e0x02', '0x04', 'labs/e0x02.php', false],
                ['api0x01', '0x05', 'labs/api0x01.php', false],
                ['api0x01-2', '0x06', 'labs/api0x01.php', false],
            ],
        ],
    ],
    'injection' => [
        'name'   => 'Injection Attacks',
        'short'  => 'Injection',
        'groups' => [
            'File inclusion' => [
                ['fi0x01', '0x01', 'labs/fi0x01.php', false],
                ['fi0x02', '0x02', 'labs/fi0x02.php', false],
                ['fi0x03', '0x03', 'labs/fi0x03.php', true],
            ],
            'SQL Injection' => [
                ['i0x01', '0x01', 'labs/i0x01.php', false],
                ['i0x02', '0x02', 'labs/i0x02.php', false],
                ['i0x03', '0x03', 'labs/i0x03.php', true],
                ['i0x04', '0x04', 'labs/i0x04.php', false],
            ],
            'XSS' => [
                ['x0x01', '0x01', 'labs/x0x01.php', false],
                ['x0x02', '0x02', 'labs/x0x02.php', false],
                ['x0x03', '0x03', 'labs/x0x03.php', false],
            ],
            'Command injection' => [
                ['c0x01', '0x01', 'labs/c0x01.php', false],
                ['c0x02', '0x02', 'labs/c0x02.php', false],
                ['c0x03', '0x03', 'labs/c0x03.php', true],
            ],
            'SSTI' => [
                ['ssti0x01', '0x01', 'http://localhost:81/ssti0x01.php', false],
                ['ssti0x02', '0x02', 'http://localhost:81/ssti0x02.php', true],
            ],
            'XXE' => [
                ['e0x01', '0x01', 'labs/e0x01.php', false],
            ],
            'SSRF' => [
                ['s0x01', '0x01', 'labs/s0x01.php', false],
                ['s0x02', '0x02', 'labs/s0x02.php', false],
            ],
        ],
    ],
    'other' => [
        'name'   => 'Other Attacks',
        'short'  => 'Other',
        'groups' => [
            'File upload' => [
                ['f0x01', '0x01', 'labs/f0x01.php', false],
                ['f0x02', '0x02', 'labs/f0x02.php', false],
                ['f0x03', '0x03', 'labs/f0x03.php', false],
            ],
            'CSRF' => [
                ['csrf0x01', '0x01', 'labs/csrf0x01.php', false],
                ['csrf0x02', '0x02', 'labs/csrf0x02.php', false],
            ],
            'Open redirect' => [
                ['r0x01', '0x01', 'labs/r0x01.php', false],
            ],
            'Input validation' => [
                ['iv0x01', '0x01', 'labs/iv0x01.php', false],
            ],
        ],
    ],
];

$totalLabs = 0;
$categoryTotals = [];
foreach ($catalogue as $catId => $category) {
    $categoryTotals[$catId] = 0;
    foreach ($category['groups'] as $labs) {
        $categoryTotals[$catId] += count($labs);
    }
    $totalLabs += $categoryTotals[$catId];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bug Bounty Labs</title>
    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <link href="assets/custom.css" rel="stylesheet">
    <script src="assets/labs-ui.js"></script>
</head>

<body>
    <header class="labbar">
        <div class="labbar-inner">
            <a class="labbar-brand" href="index.php">
                <span class="labbar-mark" aria-hidden="true">0x</span>
                <span class="labbar-name">Bug Bounty Labs</span>
            </a>
            <button type="button" class="labbar-btn" data-bs-toggle="modal" data-bs-target="#instructionsModal">Instructions</button>
            <a class="labbar-btn" href="init.php"><span>Reset <span class="label-long">database</span></span></a>
            <button type="button" class="labbar-btn is-icon" data-lab-theme aria-label="Switch between light and dark theme">
                <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>
                <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
            </button>
        </div>
    </header>

    <main>
        <div class="container px-4" data-lab-catalogue>

            <section class="cat-hero">
                <div>
                    <div class="cat-eyebrow">Practical Bug Bounty &middot; v1.1</div>
                    <h1>Bug Bounty Labs</h1>
                    <p>Hands-on practice for web application testing. Pick a lab, work through it, and tick it off when
                        you are done.</p>
                </div>
                <div class="cat-progress" aria-label="Your progress">
                    <div class="cat-progress-top">
                        <svg class="cat-ring" viewBox="0 0 100 100" aria-hidden="true">
                            <circle class="track" cx="50" cy="50" r="42" />
                            <circle class="value" cx="50" cy="50" r="42" data-progress-ring />
                        </svg>
                        <div>
                            <div class="cat-count"><span data-progress-count>0</span> <small>/ <?php echo $totalLabs; ?></small></div>
                            <div class="cat-count-label">labs completed</div>
                        </div>
                    </div>
                    <div class="cat-bars">
                        <?php foreach ($catalogue as $catId => $category) { ?>
                        <div class="cat-bar" style="--cat: var(--lab-cat-<?php echo $catId; ?>)">
                            <span><?php echo $category['short']; ?></span>
                            <span class="cat-bar-track"><span class="cat-bar-fill" data-progress-bar="<?php echo $catId; ?>"></span></span>
                            <span class="cat-bar-num" data-progress-num="<?php echo $catId; ?>">0/<?php echo $categoryTotals[$catId]; ?></span>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </section>

            <?php if ($errorMessage) { ?>
            <div class="alert alert-danger" role="alert">
                <p><strong>If you just spun up the labs for the first time, this message is normal,</strong> just click
                    the link below or visit /init.php to setup the database
                    and then come back to index.php afterwards.</p>
                <p><a href="init.php">Click here to reset the database.</a></p>
                <p><?php echo $errorMessage; ?> </p>
                <p>If the issue persists, try rebuilding the application with
                    <code>sudo docker-compose up --build</code>.
                </p>
                <p class="no-margin">If that doesn't work, drop into discord and provide a screenshot of the error above.</p>
            </div>
            <?php } ?>

            <div class="cat-tools">
                <div class="cat-search">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
                    <input type="search" class="form-control" placeholder="Search labs" aria-label="Search labs" data-lab-search>
                </div>
                <div class="cat-filters" role="group" aria-label="Filter labs">
                    <button type="button" class="cat-filter" data-lab-filter="all" aria-pressed="true">All</button>
                    <?php foreach ($catalogue as $catId => $category) { ?>
                    <button type="button" class="cat-filter" data-lab-filter="<?php echo $catId; ?>" aria-pressed="false"><?php echo $category['short']; ?></button>
                    <?php } ?>
                    <button type="button" class="cat-filter" data-lab-filter="challenge" aria-pressed="false">Challenges</button>
                    <button type="button" class="cat-filter" data-lab-filter="todo" aria-pressed="false">Not completed</button>
                </div>
            </div>

            <?php foreach ($catalogue as $catId => $category) { ?>
            <section class="cat-section" data-cat="<?php echo $catId; ?>">
                <div class="cat-section-head">
                    <h2><?php echo htmlspecialchars($category['name']); ?></h2>
                    <span class="cat-section-count"><?php echo $categoryTotals[$catId]; ?> labs</span>
                </div>

                <?php foreach ($category['groups'] as $groupName => $labs) { ?>
                <div class="cat-group">
                    <div class="cat-group-name">
                        <?php echo htmlspecialchars($groupName); ?>
                        <small><?php echo count($labs); ?> <?php echo count($labs) === 1 ? 'lab' : 'labs'; ?></small>
                    </div>
                    <div class="cat-tiles">
                        <?php foreach ($labs as $lab) {
                            list($labId, $labCode, $labHref, $isChallenge) = $lab;
                            $labTitle = $groupName . ' ' . $labCode;
                        ?>
                        <div class="tile" data-lab="<?php echo $labId; ?>" data-cat="<?php echo $catId; ?>"
                            data-search="<?php echo htmlspecialchars(strtolower($labTitle . ' ' . $category['name'] . ($isChallenge ? ' challenge' : ''))); ?>"
                            <?php echo $isChallenge ? 'data-challenge' : ''; ?>>
                            <div class="tile-code"><span>0x</span><?php echo substr($labCode, 2); ?></div>
                            <div class="tile-foot">
                                <?php if ($isChallenge) { ?><span class="lab-chip">Challenge</span><?php } ?>
                                <a class="tile-link" href="<?php echo $labHref; ?>"
                                    aria-label="Access lab: <?php echo htmlspecialchars($labTitle); ?>">Open &rarr;</a>
                            </div>
                            <button type="button" class="tile-check" aria-pressed="false"
                                aria-label="Mark <?php echo htmlspecialchars($labTitle); ?> as completed">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
                            </button>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <?php } ?>
            </section>
            <?php } ?>

            <p class="cat-empty">No labs match that search.</p>
        </div>

        <!-- instructions modal -->
        <div class="modal" id="instructionsModal" tabindex="-1" aria-labelledby="instructionsModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="instructionsModalLabel">Instructions</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h2>Where to begin</h2>
                        <p>Watch the videos from the course, they will guide you through the labs and let you know
                            which ones are challenges.</p>
                        <p>This course and these labs are primarily focussed on helping you build practical skills.
                            Of course we will provide theory and support along the way but hands-on practice is the
                            only way to get good at BugBounty and Web Application Penetration Testing.</p>
                        <p>You're encouraged to test out other tools and scanners too as you go along!</p>
                        <p>I also encorage you to try out attacks you've learned on different labs (e.g. many of
                            them are vulnerable to XSS, not just the XSS ones)</p>
                        <p>To reset the lab databases, visit /init.php</p>
                        <p>If you have issues, ping us a message on discord!</p>
                        <hr>
                        <p>Good luck!</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="lab-footer">
        <p>Don't forget to take regular breaks, you got this :)</p>
        <p>Practical Bug Bounty Labs Version 1.1</p>
    </footer>

    <script src="assets/popper.min.js"></script>
    <script src="assets/bootstrap.min.js"></script>
</body>

</html>
