/*
 * Bug Bounty Labs — shared UI.
 * Loaded in <head> on every page. Handles:
 *   - light/dark theme (applied immediately to avoid a flash)
 *   - the top bar on lab pages (injected; index.php renders its own)
 *   - completion tracking in localStorage
 *   - search / filters / progress on the catalogue page
 * It only adds presentation; it never touches the lab forms or their output.
 */
(function () {
    'use strict';

    var THEME_KEY = 'bblabs.theme';
    var DONE_KEY = 'bblabs.done';
    var root = document.documentElement;

    function read(key) {
        try { return window.localStorage.getItem(key); } catch (e) { return null; }
    }

    function write(key, value) {
        try { window.localStorage.setItem(key, value); } catch (e) { /* storage unavailable */ }
    }

    // ------------------------------------------------------------------ theme

    function preferredTheme() {
        var saved = read(THEME_KEY);
        if (saved === 'light' || saved === 'dark') { return saved; }
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    function applyTheme(theme) {
        root.setAttribute('data-bs-theme', theme);
    }

    applyTheme(preferredTheme());

    function toggleTheme() {
        var next = root.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
        applyTheme(next);
        write(THEME_KEY, next);
    }

    // ------------------------------------------------------------------ progress store

    function loadDone() {
        try {
            var parsed = JSON.parse(read(DONE_KEY) || '{}');
            return parsed && typeof parsed === 'object' ? parsed : {};
        } catch (e) {
            return {};
        }
    }

    function isDone(id) { return loadDone()[id] === true; }

    function setDone(id, done) {
        var all = loadDone();
        if (done) { all[id] = true; } else { delete all[id]; }
        write(DONE_KEY, JSON.stringify(all));
    }

    // ------------------------------------------------------------------ icons

    var ICONS = {
        theme: '<svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>' +
               '<svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
        check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
        back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>'
    };

    function el(tag, className, html) {
        var node = document.createElement(tag);
        if (className) { node.className = className; }
        if (html) { node.innerHTML = html; }
        return node;
    }

    // ------------------------------------------------------------------ lab pages: top bar

    // Helper pages share the completion state of the lab they belong to.
    var PAGE_ALIASES = { a0x02code: 'a0x02', r0x01_script: 'r0x01', x0x03_admin: 'x0x03' };

    function currentLabId() {
        var file = window.location.pathname.split('/').pop().replace(/\.php$/, '');
        return PAGE_ALIASES[file] || file;
    }

    function buildLabBar() {
        var crumb = document.querySelector('h2.border-bottom a');
        var heading = crumb ? crumb.parentNode : null;
        var homeHref = crumb ? crumb.getAttribute('href') : '../index.php';
        var sameSite = true;
        try {
            sameSite = new URL(homeHref, window.location.href).origin === window.location.origin;
        } catch (e) { /* keep default */ }

        var bar = el('header', 'labbar');
        var inner = el('div', 'labbar-inner');
        bar.appendChild(inner);

        var brand = el('a', 'labbar-brand',
            '<span class="labbar-mark" aria-hidden="true">0x</span><span class="labbar-name">Bug Bounty Labs</span>');
        brand.href = homeHref;
        inner.appendChild(brand);

        if (heading && /\[challenge\]/i.test(heading.textContent)) {
            inner.appendChild(el('span', 'lab-chip', 'Challenge'));
        }

        var back = el('a', 'labbar-btn', ICONS.back + '<span>All labs</span>');
        back.href = homeHref;
        inner.appendChild(back);

        // Progress lives in this origin's localStorage, so the toggle is only
        // offered on pages served from the same origin as the catalogue.
        if (sameSite && heading) {
            var id = currentLabId();
            var done = el('button', 'labbar-btn',
                ICONS.check + '<span class="when-off">Mark <span class="label-long">as </span>complete</span><span class="when-on">Completed</span>');
            done.type = 'button';
            done.setAttribute('aria-pressed', isDone(id) ? 'true' : 'false');
            done.addEventListener('click', function () {
                var now = done.getAttribute('aria-pressed') !== 'true';
                done.setAttribute('aria-pressed', now ? 'true' : 'false');
                setDone(id, now);
            });
            inner.appendChild(done);
        }

        var theme = el('button', 'labbar-btn is-icon', ICONS.theme);
        theme.type = 'button';
        theme.setAttribute('aria-label', 'Switch between light and dark theme');
        theme.addEventListener('click', toggleTheme);
        inner.appendChild(theme);

        document.body.insertBefore(bar, document.body.firstChild);
    }

    // ------------------------------------------------------------------ catalogue page

    function initCatalogue(catalogue) {
        var tiles = Array.prototype.slice.call(catalogue.querySelectorAll('.tile'));
        var sections = Array.prototype.slice.call(catalogue.querySelectorAll('.cat-section'));
        var groups = Array.prototype.slice.call(catalogue.querySelectorAll('.cat-group'));
        var search = document.querySelector('[data-lab-search]');
        var filters = Array.prototype.slice.call(document.querySelectorAll('[data-lab-filter]'));
        var empty = document.querySelector('.cat-empty');
        var activeFilter = 'all';

        function renderProgress() {
            var done = loadDone();
            var total = 0;
            var complete = 0;
            var perCat = {};

            tiles.forEach(function (tile) {
                var id = tile.getAttribute('data-lab');
                var cat = tile.getAttribute('data-cat');
                var isComplete = done[id] === true;
                tile.classList.toggle('is-done', isComplete);
                var check = tile.querySelector('.tile-check');
                check.setAttribute('aria-pressed', isComplete ? 'true' : 'false');
                perCat[cat] = perCat[cat] || { total: 0, done: 0 };
                perCat[cat].total += 1;
                total += 1;
                if (isComplete) { perCat[cat].done += 1; complete += 1; }
            });

            var countNode = document.querySelector('[data-progress-count]');
            if (countNode) { countNode.textContent = complete; }

            var ring = document.querySelector('[data-progress-ring]');
            if (ring) {
                var length = 2 * Math.PI * ring.r.baseVal.value;
                ring.style.strokeDasharray = length;
                ring.style.strokeDashoffset = length * (1 - (total ? complete / total : 0));
            }

            Object.keys(perCat).forEach(function (cat) {
                var fill = document.querySelector('[data-progress-bar="' + cat + '"]');
                var num = document.querySelector('[data-progress-num="' + cat + '"]');
                if (fill) { fill.style.width = (100 * perCat[cat].done / perCat[cat].total) + '%'; }
                if (num) { num.textContent = perCat[cat].done + '/' + perCat[cat].total; }
            });
        }

        function applyFilters() {
            var query = search ? search.value.trim().toLowerCase() : '';
            var done = loadDone();
            var shown = 0;

            tiles.forEach(function (tile) {
                var matchesQuery = !query || tile.getAttribute('data-search').indexOf(query) !== -1;
                var matchesFilter = true;
                if (activeFilter === 'challenge') {
                    matchesFilter = tile.hasAttribute('data-challenge');
                } else if (activeFilter === 'todo') {
                    matchesFilter = done[tile.getAttribute('data-lab')] !== true;
                } else if (activeFilter !== 'all') {
                    matchesFilter = tile.getAttribute('data-cat') === activeFilter;
                }
                var visible = matchesQuery && matchesFilter;
                tile.hidden = !visible;
                if (visible) { shown += 1; }
            });

            groups.concat(sections).forEach(function (block) {
                block.hidden = !block.querySelector('.tile:not([hidden])');
            });

            if (empty) { empty.classList.toggle('is-shown', shown === 0); }
        }

        tiles.forEach(function (tile) {
            tile.querySelector('.tile-check').addEventListener('click', function () {
                var id = tile.getAttribute('data-lab');
                setDone(id, !isDone(id));
                renderProgress();
                applyFilters();
            });
        });

        filters.forEach(function (button) {
            button.addEventListener('click', function () {
                activeFilter = button.getAttribute('data-lab-filter');
                filters.forEach(function (other) {
                    other.setAttribute('aria-pressed', other === button ? 'true' : 'false');
                });
                applyFilters();
            });
        });

        if (search) { search.addEventListener('input', applyFilters); }

        // Keep the catalogue in sync when a lab is marked complete in another tab.
        window.addEventListener('storage', function (event) {
            if (event.key === DONE_KEY) { renderProgress(); applyFilters(); }
        });

        renderProgress();
        applyFilters();
    }

    // ------------------------------------------------------------------ boot

    function boot() {
        var themeButtons = document.querySelectorAll('[data-lab-theme]');
        Array.prototype.forEach.call(themeButtons, function (button) {
            button.addEventListener('click', toggleTheme);
        });

        var catalogue = document.querySelector('[data-lab-catalogue]');
        if (catalogue) {
            initCatalogue(catalogue);
        } else if (!document.querySelector('.labbar')) {
            buildLabBar();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
